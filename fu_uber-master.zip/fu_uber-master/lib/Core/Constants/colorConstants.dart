import 'package:flutter/cupertino.dart';

class ConstantColors {
  static const Color PrimaryColor = Color(0xff656d74);
  static const Color ActivePink = Color(0xfffb376a);
  static const Color DeepBlue = Color(0xff13034d);
}
