class AuthPrefs {}
