class RideDetail {}
