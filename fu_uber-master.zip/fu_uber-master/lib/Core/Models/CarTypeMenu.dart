import 'package:fu_uber/Core/Enums/Enums.dart';

class CarTypeMenu {
  final String image;
  final String info;
  final RideType rideType;

  CarTypeMenu(this.image, this.info, this.rideType);
}
