import 'package:google_maps_flutter/google_maps_flutter.dart';

class UserPlaces {
  String title;
  String name;
  LatLng location;

  UserPlaces(this.title, this.name, this.location);
}
