enum AuthStatus { Authenticated, UnAuthenticated }
enum RideType { Affordable, Classic, Sedan, Suv, Luxury }
enum DriverStatus { Booked, OnWay, Reached, InRoute, Free }
